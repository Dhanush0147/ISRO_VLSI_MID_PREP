%% ========================================================================
%  Batch Convert Simulink Models (2025 → 2024)
%  Root folder containing all your subfolders and models:
%  D:\MATLAB\MATLAB_SIMULINK_MODELS
% ========================================================================

clc; clear;

rootFolder = 'D:\MATLAB\MATLAB_SIMULINK_MODELS';

% Find all .slx and .mdl files recursively
slxFiles = dir(fullfile(rootFolder, '**', '*.slx'));
mdlFiles = dir(fullfile(rootFolder, '**', '*.mdl'));

allFiles = [slxFiles; mdlFiles];

fprintf('\nFound %d Simulink model files.\n\n', length(allFiles));

for k = 1:length(allFiles)

    filePath = fullfile(allFiles(k).folder, allFiles(k).name);
    fprintf('Converting (%d/%d): %s\n', k, length(allFiles), filePath);

    try
        % Load the model silently
        sys = load_system(filePath);     % returns model name/handle

        % Save model in the current MATLAB/Simulink version (2024)
        save_system(sys);

        % Close model without asking to save
        close_system(sys, 0);

        fprintf('   ✓ Success\n');

    catch ME
        fprintf('   ✗ FAILED: %s\n', ME.message);
    end
end

fprintf('\n=========================================\n');
fprintf('   DONE — All Possible Models Converted!\n');
fprintf('=========================================\n\n');